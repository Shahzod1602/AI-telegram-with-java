
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

public class JavaAssistantBot extends TelegramLongPollingBot {
    private final String botToken;
    private final String botUsername;
    private final OpenAIService openAIService;

    public JavaAssistantBot(String botToken, String botUsername, String openaiApiKey) {
        this.botToken = botToken;
        this.botUsername = botUsername;
        this.openAIService = new OpenAIService(openaiApiKey);
    }

    @Override
    public String getBotUsername() {
        return botUsername;
    }

    @Override
    public String getBotToken() {
        return botToken;
    }

    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasMessage() && update.getMessage().hasText()) {
            Message message = update.getMessage();
            String userMessage = message.getText();
            Long chatId = message.getChatId();

            // Handle /start command
            if (userMessage.equals("/start")) {
                sendMessage(chatId, "👋 Hello! I'm your Java Assistant Bot!\n\n" +
                    "Ask me any Java programming questions and I'll help you with:\n" +
                    "• Java syntax and concepts\n" +
                    "• Best practices\n" +
                    "• Code examples\n" +
                    "• Troubleshooting\n" +
                    "• And much more!\n\n" +
                    "Just type your Java question and I'll provide a detailed answer!");
                return;
            }

            // Handle /help command
            if (userMessage.equals("/help")) {
                sendMessage(chatId, "ℹ️ How to use this bot:\n\n" +
                    "Simply ask me any Java-related question, for example:\n" +
                    "• \"What is the difference between ArrayList and LinkedList?\"\n" +
                    "• \"How do I handle exceptions in Java?\"\n" +
                    "• \"Explain Java inheritance\"\n" +
                    "• \"Show me how to use HashMap\"\n\n" +
                    "I'll provide clear explanations and code examples!");
                return;
            }

            // Send typing action
            sendTypingAction(chatId);

            // Get AI response
            String aiResponse = openAIService.getJavaResponse(userMessage);
            sendMessage(chatId, aiResponse);
        }
    }

    private void sendMessage(Long chatId, String text) {
        SendMessage message = new SendMessage();
        message.setChatId(chatId.toString());
        message.setText(text);
        
        try {
            execute(message);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }

    private void sendTypingAction(Long chatId) {
        try {
            org.telegram.telegrambots.meta.api.methods.send.SendChatAction sendChatAction = 
                new org.telegram.telegrambots.meta.api.methods.send.SendChatAction();
            sendChatAction.setChatId(chatId.toString());
            sendChatAction.setAction(org.telegram.telegrambots.meta.api.methods.ActionType.TYPING);
            execute(sendChatAction);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }
}
