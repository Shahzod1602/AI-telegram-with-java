import org.telegram.telegrambots.meta.TelegramBotsApi;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import org.telegram.telegrambots.updatesreceivers.DefaultBotSession;

public class Main {
    public static void main(String[] args) {
        // Get environment variables
        String telegramBotToken = System.getenv("TELEGRAM_BOT_TOKEN");
        String telegramBotUsername = System.getenv("TELEGRAM_BOT_USERNAME");
        String openaiApiKey = System.getenv("OPENAI_API_KEY");

        // Validate environment variables
        if (telegramBotToken == null || telegramBotToken.isEmpty()) {
            System.err.println("❌ TELEGRAM_BOT_TOKEN environment variable is not set!");
            System.err.println("Please set your Telegram bot token in the Secrets tab.");
            return;
        }

        if (telegramBotUsername == null || telegramBotUsername.isEmpty()) {
            System.err.println("❌ TELEGRAM_BOT_USERNAME environment variable is not set!");
            System.err.println("Please set your Telegram bot username in the Secrets tab.");
            return;
        }

        if (openaiApiKey == null || openaiApiKey.isEmpty()) {
            System.err.println("❌ OPENAI_API_KEY environment variable is not set!");
            System.err.println("Please set your OpenAI API key in the Secrets tab.");
            return;
        }

        try {
            // Initialize Telegram Bots API
            TelegramBotsApi botsApi = new TelegramBotsApi(DefaultBotSession.class);

            // Create and register the bot
            JavaAssistantBot bot = new JavaAssistantBot(telegramBotToken, telegramBotUsername, openaiApiKey);
            botsApi.registerBot(bot);

            System.out.println("🤖 Java Assistant Bot is running!");
            System.out.println("✅ Bot Username: @" + telegramBotUsername);
            System.out.println("📱 The bot is now ready to receive messages on Telegram!");

        } catch (TelegramApiException e) {
            System.err.println("❌ Error starting the bot: " + e.getMessage());
            e.printStackTrace();
        }
    }
}