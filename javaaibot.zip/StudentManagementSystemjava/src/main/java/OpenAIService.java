
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;
import java.io.IOException;

public class OpenAIService {
    private static final String OPENAI_API_URL = "https://api.openai.com/v1/chat/completions";
    private final String apiKey;
    private final OkHttpClient client;
    private final ObjectMapper objectMapper;

    public OpenAIService(String apiKey) {
        this.apiKey = apiKey;
        this.client = new OkHttpClient();
        this.objectMapper = new ObjectMapper();
    }

    public String getJavaResponse(String question) {
        try {
            String jsonBody = String.format(
                "{"
                + "\"model\": \"gpt-4o\","
                + "\"messages\": ["
                + "  {"
                + "    \"role\": \"system\","
                + "    \"content\": \"You are a helpful Java programming assistant. Provide clear, accurate, and practical answers about Java programming concepts, syntax, best practices, and troubleshooting. Keep responses concise but informative.\""
                + "  },"
                + "  {"
                + "    \"role\": \"user\","
                + "    \"content\": \"%s\""
                + "  }"
                + "],"
                + "\"max_tokens\": 1000,"
                + "\"temperature\": 0.7"
                + "}",
                question.replace("\"", "\\\"").replace("\n", "\\n")
            );

            RequestBody body = RequestBody.create(
                jsonBody,
                MediaType.parse("application/json")
            );

            Request request = new Request.Builder()
                .url(OPENAI_API_URL)
                .post(body)
                .addHeader("Authorization", "Bearer " + apiKey)
                .addHeader("Content-Type", "application/json")
                .build();

            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    return "Sorry, I'm having trouble connecting to the AI service right now. Please try again later.";
                }

                String responseBody = response.body().string();
                JsonNode jsonNode = objectMapper.readTree(responseBody);
                
                if (jsonNode.has("choices") && jsonNode.get("choices").size() > 0) {
                    return jsonNode.get("choices").get(0)
                        .get("message").get("content").asText().trim();
                } else {
                    return "Sorry, I couldn't generate a response. Please try rephrasing your question.";
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            return "An error occurred while processing your request: " + e.getMessage();
        }
    }
}
